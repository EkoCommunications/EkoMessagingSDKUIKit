//
//  EkoUIKit.h
//  EkoUIKit
//
//  Created by Michael Abadi Santoso on 5/28/20.
//  Copyright © 2020 Eko Communication. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for EkoUIKit.
FOUNDATION_EXPORT double EkoUIKitVersionNumber;

//! Project version string for EkoUIKit.
FOUNDATION_EXPORT const unsigned char EkoUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EkoUIKit/PublicHeader.h>


